--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.7 (Debian 11.7-0+deb10u1)
-- Dumped by pg_dump version 11.7 (Debian 11.7-0+deb10u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE gmi;
--
-- Name: gmi; Type: DATABASE; Schema: -; Owner: gmc
--

CREATE DATABASE gmi WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'ru_RU.UTF-8' LC_CTYPE = 'ru_RU.UTF-8';


ALTER DATABASE gmi OWNER TO gmc;

\connect gmi

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: aerp; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.aerp (
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    num integer NOT NULL,
    d0 smallint,
    f0 smallint,
    d9 smallint,
    f9 smallint,
    d8 smallint,
    f8 smallint,
    d7 smallint,
    f7 smallint,
    d5 smallint,
    f5 smallint,
    d4 smallint,
    f4 smallint,
    d3 smallint,
    f3 smallint,
    d25 smallint,
    f25 smallint,
    d2 smallint,
    f2 smallint,
    d15 smallint,
    f15 smallint,
    d1 smallint,
    f1 smallint
);


ALTER TABLE public.aerp OWNER TO postgres;

--
-- Name: aert; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.aert (
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    num integer NOT NULL,
    h0 smallint,
    t0 smallint,
    r0 smallint,
    d0 smallint,
    f0 smallint,
    h9 smallint,
    t9 smallint,
    r9 smallint,
    d9 smallint,
    f9 smallint,
    h8 smallint,
    t8 smallint,
    r8 smallint,
    d8 smallint,
    f8 smallint,
    h7 smallint,
    t7 smallint,
    r7 smallint,
    d7 smallint,
    f7 smallint,
    h5 smallint,
    t5 smallint,
    r5 smallint,
    d5 smallint,
    f5 smallint,
    h4 smallint,
    t4 smallint,
    r4 smallint,
    d4 smallint,
    f4 smallint,
    h3 smallint,
    t3 smallint,
    r3 smallint,
    d3 smallint,
    f3 smallint,
    h25 smallint,
    t25 smallint,
    r25 smallint,
    d25 smallint,
    f25 smallint,
    h2 smallint,
    t2 smallint,
    r2 smallint,
    d2 smallint,
    f2 smallint,
    h15 smallint,
    t15 smallint,
    r15 smallint,
    d15 smallint,
    f15 smallint,
    h1 smallint,
    t1 smallint,
    r1 smallint,
    d1 smallint,
    f1 smallint
);


ALTER TABLE public.aert OWNER TO postgres;

--
-- Name: fa12; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fa12 (
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    num integer NOT NULL,
    rr character(4)
);


ALTER TABLE public.fa12 OWNER TO postgres;

--
-- Name: fa20; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fa20 (
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    num integer NOT NULL,
    latc smallint,
    lngc smallint,
    msg text
);


ALTER TABLE public.fa20 OWNER TO postgres;

--
-- Name: farp; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.farp (
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    lat smallint NOT NULL,
    lng smallint NOT NULL,
    id character varying(16) NOT NULL,
    h smallint NOT NULL,
    t smallint,
    dd smallint,
    ff smallint,
    step smallint,
    msg text
);


ALTER TABLE public.farp OWNER TO postgres;

--
-- Name: fars; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fars (
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    lat smallint,
    lng smallint,
    id character varying(16) NOT NULL,
    msg text NOT NULL,
    h smallint NOT NULL,
    hd smallint
);


ALTER TABLE public.fars OWNER TO postgres;

--
-- Name: fb11; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fb11 (
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    num integer NOT NULL,
    dv character(2),
    tw smallint,
    sea1 character(4),
    sea2 character(4),
    sea3 character(4),
    sea4 character(4),
    sea5 character(4),
    sea6 character(4),
    hw smallint,
    tb smallint
);


ALTER TABLE public.fb11 OWNER TO postgres;

--
-- Name: fb12; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fb12 (
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    num integer NOT NULL,
    dv character(2),
    tw smallint,
    sea1 character(4),
    sea2 character(4),
    sea3 character(4),
    sea4 character(4),
    sea5 character(4),
    sea6 character(4),
    hw smallint,
    tb smallint
);


ALTER TABLE public.fb12 OWNER TO postgres;

--
-- Name: fb13; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fb13 (
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    nik character varying(24),
    lat smallint NOT NULL,
    lng smallint NOT NULL,
    dv character(2),
    tw smallint,
    sea1 character(4),
    sea2 character(4),
    sea3 character(4),
    sea4 character(4),
    sea5 character(4),
    sea6 character(4),
    hw smallint,
    tb smallint
);


ALTER TABLE public.fb13 OWNER TO postgres;

--
-- Name: fb18; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fb18 (
    num character(5) NOT NULL,
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    lat smallint NOT NULL,
    lng smallint NOT NULL,
    qq character(2),
    tw smallint,
    p smallint,
    h smallint,
    pw smallint,
    hw smallint
);


ALTER TABLE public.fb18 OWNER TO postgres;

--
-- Name: fb20; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fb20 (
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    num integer NOT NULL,
    msg text
);


ALTER TABLE public.fb20 OWNER TO postgres;

--
-- Name: fc11; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fc11 (
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    num integer NOT NULL,
    g0 character(4),
    g1 smallint,
    g2 smallint,
    g3 character(4),
    g4 character(4),
    g5_10 character(4),
    g5_11 character(5),
    g5_12 character(5),
    g5_20 character(4),
    g5_21 character(5),
    g5_22 character(5),
    g6 character(4),
    g7 character(4),
    g8_1 character(4),
    g8_2 character(4),
    g8_3 character(4),
    g9_1 character(4),
    g9_2 character(4),
    g9_3 character(4)
);


ALTER TABLE public.fc11 OWNER TO postgres;

--
-- Name: fc12; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fc12 (
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    num integer NOT NULL,
    g0 character(4),
    g1 smallint,
    g2 smallint,
    g3 character(4),
    g4 character(4),
    g5_10 character(4),
    g5_11 character(5),
    g5_12 character(5),
    g5_20 character(4),
    g5_21 character(5),
    g5_22 character(5),
    g6 character(4),
    g7 character(4),
    g8_1 character(4),
    g8_2 character(4),
    g8_3 character(4),
    g9_1 character(4),
    g9_2 character(4),
    g9_3 character(4)
);


ALTER TABLE public.fc12 OWNER TO postgres;

--
-- Name: fc13; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fc13 (
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    nik character varying(24),
    lat smallint NOT NULL,
    lng smallint NOT NULL,
    g0 character(4),
    g1 smallint,
    g2 smallint,
    g3 character(4),
    g4 character(4),
    g5_10 character(4),
    g5_11 character(5),
    g5_12 character(5),
    g5_20 character(4),
    g5_21 character(5),
    g5_22 character(5),
    g6 character(4),
    g7 character(4),
    g8_1 character(4),
    g8_2 character(4),
    g8_3 character(4),
    g9_1 character(4),
    g9_2 character(4),
    g9_3 character(4)
);


ALTER TABLE public.fc13 OWNER TO postgres;

--
-- Name: fc14; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fc14 (
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    nik character varying(24),
    lat smallint NOT NULL,
    lng smallint NOT NULL,
    mmu character(5),
    hhi character(5),
    g0 character(4),
    g1 smallint,
    g2 smallint,
    g3 character(4),
    g4 character(4),
    g5_10 character(4),
    g5_11 character(5),
    g5_12 character(5),
    g5_20 character(4),
    g5_21 character(5),
    g5_22 character(5),
    g6 character(4),
    g7 character(4),
    g8_1 character(4),
    g8_2 character(4),
    g8_3 character(4),
    g9_1 character(4),
    g9_2 character(4),
    g9_3 character(4)
);


ALTER TABLE public.fc14 OWNER TO postgres;

--
-- Name: fc18; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fc18 (
    num character(5) NOT NULL,
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    lat smallint NOT NULL,
    lng smallint NOT NULL,
    qq character(2),
    k8 character(1),
    t8 text,
    k6 character(2),
    t6 text
);


ALTER TABLE public.fc18 OWNER TO postgres;

--
-- Name: fc20; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fc20 (
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    num integer NOT NULL,
    msg text
);


ALTER TABLE public.fc20 OWNER TO postgres;

--
-- Name: fd12; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fd12 (
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    num integer NOT NULL,
    clouds text NOT NULL
);


ALTER TABLE public.fd12 OWNER TO postgres;

--
-- Name: fd18; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fd18 (
    num character(5) NOT NULL,
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    lat smallint NOT NULL,
    lng smallint NOT NULL,
    part4 text NOT NULL
);


ALTER TABLE public.fd18 OWNER TO postgres;

--
-- Name: fe12; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fe12 (
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    num integer NOT NULL,
    g0 character(4),
    g1 character(4),
    g2 character(4),
    g3 character(4),
    g4 character(4),
    g51 character(4),
    g52 character(4),
    g53 character(4),
    g61 character(4),
    g62 character(4),
    g7 character(4),
    g8 character(4),
    g91 character(4),
    g92 character(4),
    g93 character(4)
);


ALTER TABLE public.fe12 OWNER TO postgres;

--
-- Name: fe13; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fe13 (
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    nik character varying(24),
    lat smallint NOT NULL,
    lng smallint NOT NULL,
    g0 character(4),
    g1 character(4),
    g2 character(4),
    g3 character(4),
    g4 character(4),
    g51 character(4),
    g52 character(4),
    g53 character(4),
    g61 character(4),
    g62 character(4),
    g7 character(4),
    g8 character(4),
    g91 character(4),
    g92 character(4),
    g93 character(4)
);


ALTER TABLE public.fe13 OWNER TO postgres;

--
-- Name: ffpa; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ffpa (
    id character(4) NOT NULL,
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    n character varying(8),
    c character varying(12),
    h character varying(12),
    w character varying(12),
    v smallint,
    d smallint,
    f smallint,
    ff smallint,
    t smallint,
    r smallint
);


ALTER TABLE public.ffpa OWNER TO postgres;

--
-- Name: fm11; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fm11 (
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    num integer NOT NULL,
    h character(1),
    vv smallint,
    n character(1),
    dd smallint,
    ff smallint,
    ts smallint,
    tdr smallint,
    ps smallint,
    pm smallint,
    sd character(1),
    dp smallint,
    w smallint,
    w1 smallint,
    w2 smallint,
    c character(4)
);


ALTER TABLE public.fm11 OWNER TO postgres;

--
-- Name: fm12; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fm12 (
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    num integer NOT NULL,
    h character(1),
    vv smallint,
    n character(1),
    dd smallint,
    ff smallint,
    ts smallint,
    tdr smallint,
    ps smallint,
    pm smallint,
    sd character(1),
    dp smallint,
    w smallint,
    w1 smallint,
    w2 smallint,
    c character(4)
);


ALTER TABLE public.fm12 OWNER TO postgres;

--
-- Name: fm13; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fm13 (
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    nik character varying(24),
    lat smallint NOT NULL,
    lng smallint NOT NULL,
    h character(1),
    vv smallint,
    n character(1),
    dd smallint,
    ff smallint,
    ts smallint,
    tdr smallint,
    ps smallint,
    pm smallint,
    sd character(1),
    dp smallint,
    w smallint,
    w1 smallint,
    w2 smallint,
    c character(4)
);


ALTER TABLE public.fm13 OWNER TO postgres;

--
-- Name: fm14; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fm14 (
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    nik character varying(24),
    lat smallint NOT NULL,
    lng smallint NOT NULL,
    mmu character(5),
    hhi character(5),
    h character(1),
    vv smallint,
    n character(1),
    dd smallint,
    ff smallint,
    ts smallint,
    tdr smallint,
    ps smallint,
    pm smallint,
    sd character(1),
    dp smallint,
    w smallint,
    w1 smallint,
    w2 smallint,
    c character(4)
);


ALTER TABLE public.fm14 OWNER TO postgres;

--
-- Name: fm15; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fm15 (
    id character(4) NOT NULL,
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    type character(1),
    cor character(1) NOT NULL,
    msg text NOT NULL
);


ALTER TABLE public.fm15 OWNER TO postgres;

--
-- Name: fm18; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fm18 (
    num character(5) NOT NULL,
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    lat smallint NOT NULL,
    lng smallint NOT NULL,
    qq character(2),
    dd smallint,
    ff smallint,
    ts smallint,
    tdr smallint,
    ps smallint,
    pm smallint,
    dp character(4)
);


ALTER TABLE public.fm18 OWNER TO postgres;

--
-- Name: fm32; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fm32 (
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    part character(1) NOT NULL,
    num integer NOT NULL,
    msg text NOT NULL
);


ALTER TABLE public.fm32 OWNER TO postgres;

--
-- Name: fm33; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fm33 (
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    part character(1) NOT NULL,
    nik character varying(12) NOT NULL,
    lat smallint NOT NULL,
    lng smallint NOT NULL,
    msg text NOT NULL
);


ALTER TABLE public.fm33 OWNER TO postgres;

--
-- Name: fm34; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fm34 (
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    part character(1) NOT NULL,
    nik character varying(12) NOT NULL,
    lat smallint NOT NULL,
    lng smallint NOT NULL,
    msg text NOT NULL
);


ALTER TABLE public.fm34 OWNER TO postgres;

--
-- Name: fm35; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fm35 (
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    part character(1) NOT NULL,
    num integer NOT NULL,
    msg text NOT NULL
);


ALTER TABLE public.fm35 OWNER TO postgres;

--
-- Name: fm36; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fm36 (
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    part character(1) NOT NULL,
    nik character varying(12) NOT NULL,
    lat smallint NOT NULL,
    lng smallint NOT NULL,
    msg text NOT NULL
);


ALTER TABLE public.fm36 OWNER TO postgres;

--
-- Name: fm37; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fm37 (
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    part character(1) NOT NULL,
    nik character varying(12) NOT NULL,
    lat smallint NOT NULL,
    lng smallint NOT NULL,
    msg text NOT NULL
);


ALTER TABLE public.fm37 OWNER TO postgres;

--
-- Name: fm38; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fm38 (
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    part character(1) NOT NULL,
    nik character varying(12) NOT NULL,
    lat smallint NOT NULL,
    lng smallint NOT NULL,
    msg text NOT NULL
);


ALTER TABLE public.fm38 OWNER TO postgres;

--
-- Name: fm51; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fm51 (
    id character(4) NOT NULL,
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    type character(1),
    cor character(1) NOT NULL,
    msg text NOT NULL
);


ALTER TABLE public.fm51 OWNER TO postgres;

--
-- Name: fm62; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fm62 (
    type character(1),
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    lat smallint NOT NULL,
    lng smallint NOT NULL,
    msg text NOT NULL,
    nik character varying(16)
);


ALTER TABLE public.fm62 OWNER TO postgres;

--
-- Name: fm63; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fm63 (
    type character(1),
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    lat smallint NOT NULL,
    lng smallint NOT NULL,
    msg text NOT NULL,
    nik character varying(16)
);


ALTER TABLE public.fm63 OWNER TO postgres;

--
-- Name: fm64; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fm64 (
    type character(1),
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    lat smallint NOT NULL,
    lng smallint NOT NULL,
    msg text NOT NULL,
    nik character varying(16)
);


ALTER TABLE public.fm64 OWNER TO postgres;

--
-- Name: fm65; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fm65 (
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    nik character varying(16),
    lat smallint NOT NULL,
    lng smallint NOT NULL,
    msg text NOT NULL
);


ALTER TABLE public.fm65 OWNER TO postgres;

--
-- Name: fm67; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fm67 (
    num integer NOT NULL,
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    type character(2) NOT NULL,
    part character(1) NOT NULL,
    msg text NOT NULL
);


ALTER TABLE public.fm67 OWNER TO postgres;

--
-- Name: fmet; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fmet (
    id character(4) NOT NULL,
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    dte timestamp without time zone NOT NULL,
    type character(1) NOT NULL,
    num character varying(3) NOT NULL,
    msg text
);


ALTER TABLE public.fmet OWNER TO postgres;

--
-- Name: fmgg; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fmgg (
    num integer NOT NULL,
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    type character(5) NOT NULL,
    msg text NOT NULL
);


ALTER TABLE public.fmgg OWNER TO postgres;

--
-- Name: fppa; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fppa (
    id character(4) NOT NULL,
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    prd character varying(12),
    msg text NOT NULL
);


ALTER TABLE public.fppa OWNER TO postgres;

--
-- Name: fwra; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fwra (
    id character(4) NOT NULL,
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    prd character varying(12),
    msg text NOT NULL
);


ALTER TABLE public.fwra OWNER TO postgres;

--
-- Name: fwrn; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fwrn (
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    trend character(1) NOT NULL,
    num integer NOT NULL,
    msg text NOT NULL
);


ALTER TABLE public.fwrn OWNER TO postgres;

--
-- Name: fwrp; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fwrp (
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    trend character(1) NOT NULL,
    type character(1) NOT NULL,
    num integer NOT NULL,
    event smallint NOT NULL,
    msg text
);


ALTER TABLE public.fwrp OWNER TO postgres;

--
-- Name: ices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ices (
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    msg text NOT NULL,
    id character(1) NOT NULL
);


ALTER TABLE public.ices OWNER TO postgres;

--
-- Name: kd24; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kd24 (
    num integer NOT NULL,
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    d7 date,
    d8 date,
    d9 date,
    d0 date
);


ALTER TABLE public.kd24 OWNER TO postgres;

--
-- Name: kn15; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kn15 (
    num integer NOT NULL,
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    part smallint NOT NULL,
    p1 smallint,
    p2 smallint,
    p3 smallint,
    p4_1 smallint,
    p4_2 smallint,
    p5_1a smallint,
    p5_2a smallint,
    p5_1b smallint,
    p5_2b smallint,
    p5_1c smallint,
    p5_2c smallint,
    p5_1d smallint,
    p5_2d smallint,
    p5_1e smallint,
    p5_2e smallint,
    p6_1a smallint,
    p6_2a smallint,
    p6_1b smallint,
    p6_2b smallint,
    p6_1c smallint,
    p6_2c smallint,
    p6_1d smallint,
    p6_2d smallint,
    p6_1e smallint,
    p6_2e smallint,
    p7_1 smallint,
    p7_2 smallint,
    p8_1 smallint,
    p8_2 smallint,
    p0_1 smallint,
    p0_2 smallint
);


ALTER TABLE public.kn15 OWNER TO postgres;

--
-- Name: kn21; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kn21 (
    num integer NOT NULL,
    dta timestamp without time zone NOT NULL,
    d date NOT NULL,
    cor character(1) NOT NULL,
    part character(1) NOT NULL,
    msg text NOT NULL
);


ALTER TABLE public.kn21 OWNER TO postgres;

--
-- Name: kn24; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kn24 (
    num integer NOT NULL,
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    s1 character(3),
    k1 character(1),
    d2 character(2),
    l2 character(2),
    r3 character(3),
    e3 character(1),
    s4 character(3),
    k4 character(1),
    d5 character(2),
    l5 character(2),
    r6 character(3),
    e6 character(1)
);


ALTER TABLE public.kn24 OWNER TO postgres;

--
-- Name: kna2; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kna2 (
    num integer NOT NULL,
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    obj smallint NOT NULL,
    dd smallint,
    ff smallint,
    ff_max smallint,
    v smallint,
    w smallint,
    ts smallint,
    tw smallint,
    ib smallint,
    hw smallint,
    hw_max smallint,
    pw smallint,
    dw1 smallint,
    dw2 smallint,
    b1 smallint,
    b2 smallint,
    hn smallint,
    ah smallint,
    hs smallint,
    hs_min smallint,
    hs_max smallint
);


ALTER TABLE public.kna2 OWNER TO postgres;

--
-- Name: knb2; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.knb2 (
    num integer NOT NULL,
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    obj smallint NOT NULL,
    q smallint,
    nf smallint,
    l smallint,
    qqq smallint,
    hs smallint,
    nw smallint,
    dw smallint,
    ni smallint,
    di smallint,
    p smallint,
    s smallint,
    f smallint,
    xp smallint,
    xf smallint,
    hp smallint,
    zf smallint,
    xi smallint,
    xn smallint,
    zi smallint,
    fn smallint,
    fd smallint,
    dd smallint,
    a1 smallint,
    a2 smallint,
    a3 smallint,
    a4 smallint,
    a5 smallint
);


ALTER TABLE public.knb2 OWNER TO postgres;

--
-- Name: knc2; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.knc2 (
    num integer NOT NULL,
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    obj smallint NOT NULL,
    t smallint,
    tw smallint,
    g90 character(4),
    g91 character(4)
);


ALTER TABLE public.knc2 OWNER TO postgres;

--
-- Name: pagrs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pagrs (
    num integer NOT NULL,
    rgn smallint,
    lat smallint,
    lng smallint,
    ru character varying(96)
);


ALTER TABLE public.pagrs OWNER TO postgres;

--
-- Name: pards; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pards (
    id character(4) NOT NULL,
    cid smallint,
    lat smallint,
    lng smallint,
    h0 smallint,
    tz smallint,
    ru character varying(64),
    kp1 smallint,
    h1 smallint,
    v1 smallint,
    kp2 smallint,
    h2 smallint,
    v2 smallint
);


ALTER TABLE public.pards OWNER TO postgres;

--
-- Name: parps; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.parps (
    id character(4) NOT NULL,
    cid smallint,
    lat smallint,
    lng smallint,
    h0 smallint,
    tz smallint,
    en character varying(64),
    ru character varying(96),
    iata character(3)
);


ALTER TABLE public.parps OWNER TO postgres;

--
-- Name: pasns; Type: TABLE; Schema: public; Owner: gmc
--

CREATE TABLE public.pasns (
    num integer NOT NULL,
    cid smallint,
    lat smallint,
    lng smallint,
    h0 smallint,
    tz smallint,
    en character varying(64),
    ru text,
    arc character(1)
);


ALTER TABLE public.pasns OWNER TO gmc;

--
-- Name: pchns; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pchns (
    num integer NOT NULL,
    id character(4) NOT NULL,
    sign smallint
);


ALTER TABLE public.pchns OWNER TO postgres;

--
-- Name: pggfs; Type: TABLE; Schema: public; Owner: gmc
--

CREATE TABLE public.pggfs (
    num integer NOT NULL,
    cid smallint,
    lat smallint,
    lng smallint,
    h0 smallint,
    tz smallint,
    en character varying(64),
    ru text
);


ALTER TABLE public.pggfs OWNER TO gmc;

--
-- Name: phdrs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.phdrs (
    num integer NOT NULL,
    cid smallint,
    tz smallint,
    lat smallint,
    lng smallint,
    ru character varying(96),
    syn integer,
    obj smallint,
    l0 smallint,
    lp smallint,
    l1 smallint,
    l2 smallint,
    arc character(1)
);


ALTER TABLE public.phdrs OWNER TO postgres;

--
-- Name: prpis; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.prpis (
    id character(4) NOT NULL,
    oms text,
    reg text
);


ALTER TABLE public.prpis OWNER TO postgres;

--
-- Name: pshps; Type: TABLE; Schema: public; Owner: gmc
--

CREATE TABLE public.pshps (
    nik character varying(24) NOT NULL,
    name character varying(32),
    imo integer,
    cid smallint,
    port character varying(32),
    type smallint,
    l smallint,
    w smallint,
    y smallint,
    v integer,
    d integer
);


ALTER TABLE public.pshps OWNER TO gmc;

--
-- Name: shtg; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shtg (
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    lat smallint NOT NULL,
    lng smallint NOT NULL,
    ip smallint,
    num smallint,
    name text,
    msg text
);


ALTER TABLE public.shtg OWNER TO postgres;

--
-- Name: ssmc; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ssmc (
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    lat smallint NOT NULL,
    lng smallint NOT NULL,
    depth smallint,
    m character varying(5),
    i character varying(7),
    reg text,
    cntr character(1) NOT NULL
);


ALTER TABLE public.ssmc OWNER TO postgres;

--
-- Name: stat; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stat (
    num integer NOT NULL,
    nik character varying(24),
    lat smallint NOT NULL,
    lng smallint NOT NULL,
    h smallint
);


ALTER TABLE public.stat OWNER TO postgres;

--
-- Name: synp; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.synp (
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    lat smallint NOT NULL,
    lng smallint NOT NULL,
    num integer,
    nik character varying(24),
    buoy character(5),
    h character(1),
    vv smallint,
    n character(1),
    dd smallint,
    ff smallint,
    ffm smallint,
    ts smallint,
    tdr smallint,
    pm smallint,
    sd character(1),
    dp smallint,
    w smallint,
    w1 smallint,
    w2 smallint,
    c character(4)
);


ALTER TABLE public.synp OWNER TO postgres;

--
-- Name: tcan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tcan (
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    name character varying(16) NOT NULL,
    lat smallint,
    lng smallint,
    d character varying(20),
    s character varying(8),
    p smallint,
    f smallint,
    f_max smallint,
    type character(1) NOT NULL,
    cntr character(1) NOT NULL
);


ALTER TABLE public.tcan OWNER TO postgres;

--
-- Name: tcbn; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tcbn (
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    name character varying(16) NOT NULL,
    lat24 smallint,
    lng24 smallint,
    r24 smallint,
    p24 smallint,
    f24 smallint,
    lat48 smallint,
    lng48 smallint,
    r48 smallint,
    p48 smallint,
    f48 smallint,
    lat72 smallint,
    lng72 smallint,
    r72 smallint,
    p72 smallint,
    f72 smallint,
    lat96 smallint,
    lng96 smallint,
    r96 smallint,
    p96 smallint,
    f96 smallint,
    lat12 smallint,
    lng12 smallint,
    r12 smallint,
    p12 smallint,
    f12 smallint,
    cntr character(1) NOT NULL
);


ALTER TABLE public.tcbn OWNER TO postgres;

--
-- Name: text; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.text (
    id integer NOT NULL,
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    type character(1) NOT NULL,
    msg text NOT NULL
);


ALTER TABLE public.text OWNER TO postgres;

--
-- Name: vlkn; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vlkn (
    dta timestamp without time zone NOT NULL,
    dt timestamp without time zone NOT NULL,
    vaac character varying(32),
    name character varying(64) NOT NULL,
    lat smallint NOT NULL,
    lng smallint NOT NULL,
    area character varying(32),
    elev character varying(24),
    num character varying(16),
    qis character varying(64),
    acc character varying(16),
    details character varying(64),
    ext text
);


ALTER TABLE public.vlkn OWNER TO postgres;

--
-- Name: aerp aerp_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.aerp
    ADD CONSTRAINT aerp_pkey PRIMARY KEY (num, dt);


--
-- Name: aert aert_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.aert
    ADD CONSTRAINT aert_pkey PRIMARY KEY (num, dt);


--
-- Name: fa12 fa12_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fa12
    ADD CONSTRAINT fa12_pkey PRIMARY KEY (num, dt);


--
-- Name: fa20 fa20_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fa20
    ADD CONSTRAINT fa20_pkey PRIMARY KEY (num, dt);


--
-- Name: farp farp_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.farp
    ADD CONSTRAINT farp_pkey PRIMARY KEY (id, dt);


--
-- Name: fars fars_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fars
    ADD CONSTRAINT fars_pkey PRIMARY KEY (id, dt);


--
-- Name: fb11 fb11_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fb11
    ADD CONSTRAINT fb11_pkey PRIMARY KEY (num, dt);


--
-- Name: fb12 fb12_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fb12
    ADD CONSTRAINT fb12_pkey PRIMARY KEY (num, dt);


--
-- Name: fb13 fb13_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fb13
    ADD CONSTRAINT fb13_pkey PRIMARY KEY (dt, lat, lng);


--
-- Name: fb18 fb18_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fb18
    ADD CONSTRAINT fb18_pkey PRIMARY KEY (dt, lat, lng);


--
-- Name: fb20 fb20_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fb20
    ADD CONSTRAINT fb20_pkey PRIMARY KEY (num, dt);


--
-- Name: fc11 fc11_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fc11
    ADD CONSTRAINT fc11_pkey PRIMARY KEY (num, dt);


--
-- Name: fc12 fc12_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fc12
    ADD CONSTRAINT fc12_pkey PRIMARY KEY (num, dt);


--
-- Name: fc13 fc13_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fc13
    ADD CONSTRAINT fc13_pkey PRIMARY KEY (dt, lat, lng);


--
-- Name: fc14 fc14_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fc14
    ADD CONSTRAINT fc14_pkey PRIMARY KEY (dt, lat, lng);


--
-- Name: fc18 fc18_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fc18
    ADD CONSTRAINT fc18_pkey PRIMARY KEY (dt, lat, lng);


--
-- Name: fc20 fc20_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fc20
    ADD CONSTRAINT fc20_pkey PRIMARY KEY (num, dt);


--
-- Name: fd12 fd12_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fd12
    ADD CONSTRAINT fd12_pkey PRIMARY KEY (num, dt);


--
-- Name: fd18 fd18_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fd18
    ADD CONSTRAINT fd18_pkey PRIMARY KEY (dt, lat, lng);


--
-- Name: fe12 fe12_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fe12
    ADD CONSTRAINT fe12_pkey PRIMARY KEY (num, dt);


--
-- Name: fe13 fe13_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fe13
    ADD CONSTRAINT fe13_pkey PRIMARY KEY (dt, lat, lng);


--
-- Name: ffpa ffpa_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ffpa
    ADD CONSTRAINT ffpa_pkey PRIMARY KEY (id, dt);


--
-- Name: fm11 fm11_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fm11
    ADD CONSTRAINT fm11_pkey PRIMARY KEY (num, dt);


--
-- Name: fm12 fm12_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fm12
    ADD CONSTRAINT fm12_pkey PRIMARY KEY (num, dt);


--
-- Name: fm13 fm13_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fm13
    ADD CONSTRAINT fm13_pkey PRIMARY KEY (dt, lat, lng);


--
-- Name: fm14 fm14_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fm14
    ADD CONSTRAINT fm14_pkey PRIMARY KEY (dt, lat, lng);


--
-- Name: fm15 fm15_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fm15
    ADD CONSTRAINT fm15_pkey PRIMARY KEY (id, dt, cor);


--
-- Name: fm18 fm18_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fm18
    ADD CONSTRAINT fm18_pkey PRIMARY KEY (dt, lat, lng);


--
-- Name: fm32 fm32_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fm32
    ADD CONSTRAINT fm32_pkey PRIMARY KEY (num, dt, part);


--
-- Name: fm33 fm33_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fm33
    ADD CONSTRAINT fm33_pkey PRIMARY KEY (dt, part, lat, lng);


--
-- Name: fm34 fm34_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fm34
    ADD CONSTRAINT fm34_pkey PRIMARY KEY (dt, part, lat, lng);


--
-- Name: fm35 fm35_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fm35
    ADD CONSTRAINT fm35_pkey PRIMARY KEY (num, dt, part);


--
-- Name: fm36 fm36_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fm36
    ADD CONSTRAINT fm36_pkey PRIMARY KEY (dt, part, lat, lng);


--
-- Name: fm37 fm37_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fm37
    ADD CONSTRAINT fm37_pkey PRIMARY KEY (dt, part, lat, lng);


--
-- Name: fm38 fm38_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fm38
    ADD CONSTRAINT fm38_pkey PRIMARY KEY (dt, part, lat, lng);


--
-- Name: fm51 fm51_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fm51
    ADD CONSTRAINT fm51_pkey PRIMARY KEY (id, dt, cor);


--
-- Name: fm62 fm62_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fm62
    ADD CONSTRAINT fm62_pkey PRIMARY KEY (dt, lat, lng);


--
-- Name: fm63 fm63_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fm63
    ADD CONSTRAINT fm63_pkey PRIMARY KEY (dt, lat, lng);


--
-- Name: fm64 fm64_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fm64
    ADD CONSTRAINT fm64_pkey PRIMARY KEY (dt, lat, lng);


--
-- Name: fm65 fm65_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fm65
    ADD CONSTRAINT fm65_pkey PRIMARY KEY (dt, lat, lng);


--
-- Name: fm67 fm67_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fm67
    ADD CONSTRAINT fm67_pkey PRIMARY KEY (num, dt, part);


--
-- Name: fmet fmet_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fmet
    ADD CONSTRAINT fmet_pkey PRIMARY KEY (id, dt, type);


--
-- Name: fmgg fmgg_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fmgg
    ADD CONSTRAINT fmgg_pkey PRIMARY KEY (num, dt, type);


--
-- Name: fppa fppa_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fppa
    ADD CONSTRAINT fppa_pkey PRIMARY KEY (id, dt);


--
-- Name: fwra fwra_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fwra
    ADD CONSTRAINT fwra_pkey PRIMARY KEY (id, dt);


--
-- Name: fwrn fwrn_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fwrn
    ADD CONSTRAINT fwrn_pkey PRIMARY KEY (num, dt);


--
-- Name: fwrp fwrp_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fwrp
    ADD CONSTRAINT fwrp_pkey PRIMARY KEY (num, dt);


--
-- Name: ices ices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ices
    ADD CONSTRAINT ices_pkey PRIMARY KEY (id, dt);


--
-- Name: kd24 kd24_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kd24
    ADD CONSTRAINT kd24_pkey PRIMARY KEY (num, dt);


--
-- Name: kn15 kn15_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kn15
    ADD CONSTRAINT kn15_pkey PRIMARY KEY (num, dt, part);


--
-- Name: kn21 kn21_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kn21
    ADD CONSTRAINT kn21_pkey PRIMARY KEY (num, d, cor, part);


--
-- Name: kn24 kn24_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kn24
    ADD CONSTRAINT kn24_pkey PRIMARY KEY (num, dt);


--
-- Name: kna2 kna2_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kna2
    ADD CONSTRAINT kna2_pkey PRIMARY KEY (num, dt, obj);


--
-- Name: knb2 knb2_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.knb2
    ADD CONSTRAINT knb2_pkey PRIMARY KEY (num, dt, obj);


--
-- Name: knc2 knc2_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.knc2
    ADD CONSTRAINT knc2_pkey PRIMARY KEY (num, dt, obj);


--
-- Name: pagrs pagrs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pagrs
    ADD CONSTRAINT pagrs_pkey PRIMARY KEY (num);


--
-- Name: pards pards_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pards
    ADD CONSTRAINT pards_pkey PRIMARY KEY (id);


--
-- Name: parps parps_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parps
    ADD CONSTRAINT parps_pkey PRIMARY KEY (id);


--
-- Name: pasns pasns_pkey; Type: CONSTRAINT; Schema: public; Owner: gmc
--

ALTER TABLE ONLY public.pasns
    ADD CONSTRAINT pasns_pkey PRIMARY KEY (num);


--
-- Name: pchns pchns_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pchns
    ADD CONSTRAINT pchns_id_key UNIQUE (id);


--
-- Name: pchns pchns_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pchns
    ADD CONSTRAINT pchns_pkey PRIMARY KEY (num);


--
-- Name: pggfs pggfs_pkey; Type: CONSTRAINT; Schema: public; Owner: gmc
--

ALTER TABLE ONLY public.pggfs
    ADD CONSTRAINT pggfs_pkey PRIMARY KEY (num);


--
-- Name: phdrs phdrs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.phdrs
    ADD CONSTRAINT phdrs_pkey PRIMARY KEY (num);


--
-- Name: prpis prpis_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.prpis
    ADD CONSTRAINT prpis_pkey PRIMARY KEY (id);


--
-- Name: pshps pshps_pkey; Type: CONSTRAINT; Schema: public; Owner: gmc
--

ALTER TABLE ONLY public.pshps
    ADD CONSTRAINT pshps_pkey PRIMARY KEY (nik);


--
-- Name: shtg shtg_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shtg
    ADD CONSTRAINT shtg_pkey PRIMARY KEY (dt, lat, lng);


--
-- Name: ssmc ssmc_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ssmc
    ADD CONSTRAINT ssmc_pkey PRIMARY KEY (dt, lat, lng, cntr);


--
-- Name: stat stat_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stat
    ADD CONSTRAINT stat_pkey PRIMARY KEY (num);


--
-- Name: synp synp_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.synp
    ADD CONSTRAINT synp_pkey PRIMARY KEY (dt, lat, lng);


--
-- Name: tcan tcan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tcan
    ADD CONSTRAINT tcan_pkey PRIMARY KEY (dt, name, cntr);


--
-- Name: tcbn tcbn_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tcbn
    ADD CONSTRAINT tcbn_pkey PRIMARY KEY (dt, name, cntr);


--
-- Name: text text_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.text
    ADD CONSTRAINT text_pkey PRIMARY KEY (id, dt, type);


--
-- Name: vlkn vlkn_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vlkn
    ADD CONSTRAINT vlkn_pkey PRIMARY KEY (dt, lat, lng, name);


--
-- Name: en_trgm_idx; Type: INDEX; Schema: public; Owner: gmc
--

CREATE INDEX en_trgm_idx ON public.pasns USING gist (en public.gist_trgm_ops);


--
-- Name: ru_trgm_idx; Type: INDEX; Schema: public; Owner: gmc
--

CREATE INDEX ru_trgm_idx ON public.pasns USING gist (ru public.gist_trgm_ops);


--
-- Name: TABLE aerp; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.aerp TO gmc;
GRANT SELECT ON TABLE public.aerp TO synop;


--
-- Name: TABLE aert; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.aert TO gmc;
GRANT SELECT ON TABLE public.aert TO synop;


--
-- Name: TABLE fa12; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fa12 TO gmc;
GRANT SELECT ON TABLE public.fa12 TO synop;


--
-- Name: TABLE fa20; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fa20 TO gmc;
GRANT SELECT ON TABLE public.fa20 TO synop;


--
-- Name: TABLE farp; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.farp TO gmc;
GRANT SELECT ON TABLE public.farp TO synop;


--
-- Name: TABLE fars; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fars TO gmc;
GRANT SELECT ON TABLE public.fars TO synop;


--
-- Name: TABLE fb11; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fb11 TO gmc;
GRANT SELECT ON TABLE public.fb11 TO synop;


--
-- Name: TABLE fb12; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fb12 TO gmc;
GRANT SELECT ON TABLE public.fb12 TO synop;


--
-- Name: TABLE fb13; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fb13 TO gmc;
GRANT SELECT ON TABLE public.fb13 TO synop;


--
-- Name: TABLE fb18; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fb18 TO gmc;
GRANT SELECT ON TABLE public.fb18 TO synop;


--
-- Name: TABLE fb20; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fb20 TO gmc;
GRANT SELECT ON TABLE public.fb20 TO synop;


--
-- Name: TABLE fc11; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fc11 TO gmc;
GRANT SELECT ON TABLE public.fc11 TO synop;


--
-- Name: TABLE fc12; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fc12 TO gmc;
GRANT SELECT ON TABLE public.fc12 TO synop;


--
-- Name: TABLE fc13; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fc13 TO gmc;
GRANT SELECT ON TABLE public.fc13 TO synop;


--
-- Name: TABLE fc14; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fc14 TO gmc;
GRANT SELECT ON TABLE public.fc14 TO synop;


--
-- Name: TABLE fc18; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fc18 TO gmc;
GRANT SELECT ON TABLE public.fc18 TO synop;


--
-- Name: TABLE fc20; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fc20 TO gmc;
GRANT SELECT ON TABLE public.fc20 TO synop;


--
-- Name: TABLE fd12; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fd12 TO gmc;
GRANT SELECT ON TABLE public.fd12 TO synop;


--
-- Name: TABLE fd18; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fd18 TO gmc;
GRANT SELECT ON TABLE public.fd18 TO synop;


--
-- Name: TABLE fe12; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fe12 TO gmc;
GRANT SELECT ON TABLE public.fe12 TO synop;


--
-- Name: TABLE fe13; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fe13 TO gmc;
GRANT SELECT ON TABLE public.fe13 TO synop;


--
-- Name: TABLE ffpa; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.ffpa TO gmc;
GRANT SELECT ON TABLE public.ffpa TO synop;


--
-- Name: TABLE fm11; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fm11 TO gmc;
GRANT SELECT ON TABLE public.fm11 TO synop;


--
-- Name: TABLE fm12; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fm12 TO gmc;
GRANT SELECT ON TABLE public.fm12 TO synop;


--
-- Name: TABLE fm13; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fm13 TO gmc;
GRANT SELECT ON TABLE public.fm13 TO synop;


--
-- Name: TABLE fm14; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fm14 TO gmc;
GRANT SELECT ON TABLE public.fm14 TO synop;


--
-- Name: TABLE fm15; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fm15 TO gmc;
GRANT SELECT ON TABLE public.fm15 TO synop;


--
-- Name: TABLE fm18; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fm18 TO gmc;
GRANT SELECT ON TABLE public.fm18 TO synop;


--
-- Name: TABLE fm32; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fm32 TO gmc;
GRANT SELECT ON TABLE public.fm32 TO synop;


--
-- Name: TABLE fm33; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fm33 TO gmc;
GRANT SELECT ON TABLE public.fm33 TO synop;


--
-- Name: TABLE fm34; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fm34 TO gmc;
GRANT SELECT ON TABLE public.fm34 TO synop;


--
-- Name: TABLE fm35; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fm35 TO gmc;
GRANT SELECT ON TABLE public.fm35 TO synop;


--
-- Name: TABLE fm36; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fm36 TO gmc;
GRANT SELECT ON TABLE public.fm36 TO synop;


--
-- Name: TABLE fm37; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fm37 TO gmc;
GRANT SELECT ON TABLE public.fm37 TO synop;


--
-- Name: TABLE fm38; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fm38 TO gmc;
GRANT SELECT ON TABLE public.fm38 TO synop;


--
-- Name: TABLE fm51; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fm51 TO gmc;
GRANT SELECT ON TABLE public.fm51 TO synop;


--
-- Name: TABLE fm62; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fm62 TO gmc;
GRANT SELECT ON TABLE public.fm62 TO synop;


--
-- Name: TABLE fm63; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fm63 TO gmc;
GRANT SELECT ON TABLE public.fm63 TO synop;


--
-- Name: TABLE fm64; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fm64 TO gmc;
GRANT SELECT ON TABLE public.fm64 TO synop;


--
-- Name: TABLE fm65; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fm65 TO gmc;
GRANT SELECT ON TABLE public.fm65 TO synop;


--
-- Name: TABLE fm67; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fm67 TO gmc;
GRANT SELECT ON TABLE public.fm67 TO synop;


--
-- Name: TABLE fmet; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fmet TO gmc;
GRANT SELECT ON TABLE public.fmet TO synop;


--
-- Name: TABLE fmgg; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fmgg TO gmc;
GRANT SELECT ON TABLE public.fmgg TO synop;


--
-- Name: TABLE fppa; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fppa TO gmc;
GRANT SELECT ON TABLE public.fppa TO synop;


--
-- Name: TABLE fwra; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fwra TO gmc;
GRANT SELECT ON TABLE public.fwra TO synop;


--
-- Name: TABLE fwrn; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fwrn TO gmc;
GRANT SELECT ON TABLE public.fwrn TO synop;


--
-- Name: TABLE fwrp; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fwrp TO gmc;
GRANT SELECT ON TABLE public.fwrp TO synop;


--
-- Name: TABLE ices; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.ices TO gmc;
GRANT SELECT ON TABLE public.ices TO synop;


--
-- Name: TABLE kd24; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.kd24 TO gmc;
GRANT SELECT ON TABLE public.kd24 TO synop;


--
-- Name: TABLE kn15; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.kn15 TO gmc;
GRANT SELECT ON TABLE public.kn15 TO synop;


--
-- Name: TABLE kn21; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.kn21 TO gmc;
GRANT SELECT ON TABLE public.kn21 TO synop;


--
-- Name: TABLE kn24; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.kn24 TO gmc;
GRANT SELECT ON TABLE public.kn24 TO synop;


--
-- Name: TABLE kna2; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.kna2 TO gmc;
GRANT SELECT ON TABLE public.kna2 TO synop;


--
-- Name: TABLE knb2; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.knb2 TO gmc;
GRANT SELECT ON TABLE public.knb2 TO synop;


--
-- Name: TABLE knc2; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.knc2 TO gmc;
GRANT SELECT ON TABLE public.knc2 TO synop;


--
-- Name: TABLE pagrs; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.pagrs TO gmc;
GRANT SELECT ON TABLE public.pagrs TO synop;


--
-- Name: TABLE pards; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.pards TO gmc;
GRANT SELECT ON TABLE public.pards TO synop;


--
-- Name: TABLE parps; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.parps TO gmc;
GRANT SELECT ON TABLE public.parps TO synop;


--
-- Name: TABLE pasns; Type: ACL; Schema: public; Owner: gmc
--

GRANT ALL ON TABLE public.pasns TO synop;


--
-- Name: TABLE pchns; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.pchns TO gmc;
GRANT ALL ON TABLE public.pchns TO synop;


--
-- Name: TABLE pggfs; Type: ACL; Schema: public; Owner: gmc
--

GRANT ALL ON TABLE public.pggfs TO synop;


--
-- Name: TABLE phdrs; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.phdrs TO gmc;
GRANT ALL ON TABLE public.phdrs TO synop;


--
-- Name: TABLE prpis; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.prpis TO gmc;
GRANT SELECT ON TABLE public.prpis TO synop;


--
-- Name: TABLE pshps; Type: ACL; Schema: public; Owner: gmc
--

GRANT ALL ON TABLE public.pshps TO synop;


--
-- Name: TABLE shtg; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.shtg TO gmc;
GRANT SELECT ON TABLE public.shtg TO synop;


--
-- Name: TABLE ssmc; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.ssmc TO gmc;
GRANT SELECT ON TABLE public.ssmc TO synop;


--
-- Name: TABLE stat; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.stat TO gmc;
GRANT SELECT ON TABLE public.stat TO synop;


--
-- Name: TABLE synp; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.synp TO gmc;
GRANT SELECT ON TABLE public.synp TO synop;


--
-- Name: TABLE tcan; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.tcan TO gmc;
GRANT SELECT ON TABLE public.tcan TO synop;


--
-- Name: TABLE tcbn; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.tcbn TO gmc;
GRANT SELECT ON TABLE public.tcbn TO synop;


--
-- Name: TABLE text; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.text TO gmc;
GRANT SELECT ON TABLE public.text TO synop;


--
-- Name: TABLE vlkn; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.vlkn TO gmc;
GRANT SELECT ON TABLE public.vlkn TO synop;


--
-- PostgreSQL database dump complete
--

