--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.7 (Debian 11.7-0+deb10u1)
-- Dumped by pg_dump version 11.7 (Debian 11.7-0+deb10u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE arc;
--
-- Name: arc; Type: DATABASE; Schema: -; Owner: gmc
--

CREATE DATABASE arc WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'ru_RU.UTF-8' LC_CTYPE = 'ru_RU.UTF-8';


ALTER DATABASE arc OWNER TO gmc;

\connect arc

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: dblink; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS dblink WITH SCHEMA public;


--
-- Name: EXTENSION dblink; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION dblink IS 'connect to other PostgreSQL databases from within a database';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: aero; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.aero (
    d date NOT NULL,
    num integer NOT NULL,
    h8 smallint,
    t8 smallint,
    r8 smallint,
    d8 smallint,
    f8 smallint,
    h7 smallint,
    t7 smallint,
    r7 smallint,
    d7 smallint,
    f7 smallint,
    h5 smallint,
    t5 smallint,
    r5 smallint,
    d5 smallint,
    f5 smallint,
    h4 smallint,
    t4 smallint,
    r4 smallint,
    d4 smallint,
    f4 smallint,
    h3 smallint,
    t3 smallint,
    r3 smallint,
    d3 smallint,
    f3 smallint,
    h25 smallint,
    t25 smallint,
    r25 smallint,
    d25 smallint,
    f25 smallint,
    h2 smallint,
    t2 smallint,
    r2 smallint,
    d2 smallint,
    f2 smallint,
    h15 smallint,
    t15 smallint,
    r15 smallint,
    d15 smallint,
    f15 smallint,
    h1 smallint,
    t1 smallint,
    r1 smallint,
    d1 smallint,
    f1 smallint
);


ALTER TABLE public.aero OWNER TO postgres;

--
-- Name: ffpa; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ffpa (
    id character(4) NOT NULL,
    dt timestamp without time zone NOT NULL,
    n character varying(8),
    c character varying(12),
    h character varying(12),
    w character varying(12),
    v smallint,
    d smallint,
    f smallint,
    ff smallint,
    t smallint,
    r smallint
);


ALTER TABLE public.ffpa OWNER TO postgres;

--
-- Name: fm12; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fm12 (
    num integer NOT NULL,
    dt timestamp without time zone NOT NULL,
    h character(1),
    vv smallint,
    n character(1),
    dd smallint,
    ff smallint,
    ts smallint,
    tdr smallint,
    ps smallint,
    w smallint,
    w1 smallint,
    w2 smallint,
    c character(4)
);


ALTER TABLE public.fm12 OWNER TO postgres;

--
-- Name: fm15; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fm15 (
    id character(4) NOT NULL,
    dt timestamp without time zone NOT NULL,
    type character(1),
    cor character(1) NOT NULL,
    msg text NOT NULL
);


ALTER TABLE public.fm15 OWNER TO postgres;

--
-- Name: fm35; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fm35 (
    num integer NOT NULL,
    dt timestamp without time zone NOT NULL,
    part character(1) NOT NULL,
    msg text NOT NULL
);


ALTER TABLE public.fm35 OWNER TO postgres;

--
-- Name: fm64; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fm64 (
    d date NOT NULL,
    lat smallint NOT NULL,
    lng smallint NOT NULL,
    msg text NOT NULL
);


ALTER TABLE public.fm64 OWNER TO postgres;

--
-- Name: fr12; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fr12 (
    num integer NOT NULL,
    d date NOT NULL,
    t time without time zone NOT NULL,
    r smallint
);


ALTER TABLE public.fr12 OWNER TO postgres;

--
-- Name: fs12; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fs12 (
    num integer NOT NULL,
    d date NOT NULL,
    s smallint
);


ALTER TABLE public.fs12 OWNER TO postgres;

--
-- Name: fv12; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fv12 (
    num integer NOT NULL,
    d date NOT NULL,
    obj smallint NOT NULL,
    nf smallint,
    l smallint,
    qqq smallint,
    hs smallint
);


ALTER TABLE public.fv12 OWNER TO postgres;

--
-- Name: fw12; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fw12 (
    num integer NOT NULL,
    dt timestamp without time zone NOT NULL,
    tw smallint
);


ALTER TABLE public.fw12 OWNER TO postgres;

--
-- Name: ices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ices (
    d date NOT NULL,
    msg text,
    id character(1) NOT NULL
);


ALTER TABLE public.ices OWNER TO postgres;

--
-- Name: kn15; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kn15 (
    num integer NOT NULL,
    dt timestamp without time zone NOT NULL,
    p1 smallint,
    p2 smallint,
    p3 smallint,
    p4_1 smallint,
    p7_1 smallint,
    p7_2 smallint,
    p0_1 smallint
);


ALTER TABLE public.kn15 OWNER TO postgres;

--
-- Name: kppo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kppo (
    num integer NOT NULL,
    d date NOT NULL,
    m integer NOT NULL
);


ALTER TABLE public.kppo OWNER TO postgres;

--
-- Name: ssmc; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ssmc (
    dt timestamp without time zone NOT NULL,
    lat smallint NOT NULL,
    lng smallint NOT NULL,
    depth smallint,
    m character varying(5),
    cntr character(1) NOT NULL
);


ALTER TABLE public.ssmc OWNER TO postgres;

--
-- Name: tmax; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tmax (
    num integer NOT NULL,
    d date NOT NULL,
    t smallint NOT NULL,
    td smallint NOT NULL
);


ALTER TABLE public.tmax OWNER TO postgres;

--
-- Name: tphn; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tphn (
    dt timestamp without time zone NOT NULL,
    name character varying(16) NOT NULL,
    lat smallint NOT NULL,
    lng smallint NOT NULL,
    p smallint,
    f smallint
);


ALTER TABLE public.tphn OWNER TO postgres;

--
-- Name: twms; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.twms (
    d date NOT NULL,
    lat smallint NOT NULL,
    lng smallint NOT NULL,
    tm smallint NOT NULL
);


ALTER TABLE public.twms OWNER TO postgres;

--
-- Name: aero aero_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.aero
    ADD CONSTRAINT aero_pkey PRIMARY KEY (d, num);


--
-- Name: ffpa ffpa_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ffpa
    ADD CONSTRAINT ffpa_pkey PRIMARY KEY (id, dt);


--
-- Name: fm12 fm12_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fm12
    ADD CONSTRAINT fm12_pkey PRIMARY KEY (num, dt);


--
-- Name: fm15 fm15_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fm15
    ADD CONSTRAINT fm15_pkey PRIMARY KEY (id, dt, cor);


--
-- Name: fm35 fm35_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fm35
    ADD CONSTRAINT fm35_pkey PRIMARY KEY (num, dt, part);


--
-- Name: fm64 fm64_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fm64
    ADD CONSTRAINT fm64_pkey PRIMARY KEY (d, lat, lng);


--
-- Name: fr12 fr12_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fr12
    ADD CONSTRAINT fr12_pkey PRIMARY KEY (num, d);


--
-- Name: fs12 fs12_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fs12
    ADD CONSTRAINT fs12_pkey PRIMARY KEY (num, d);


--
-- Name: fv12 fv12_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fv12
    ADD CONSTRAINT fv12_pkey PRIMARY KEY (num, d, obj);


--
-- Name: fw12 fw12_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fw12
    ADD CONSTRAINT fw12_pkey PRIMARY KEY (num, dt);


--
-- Name: ices ices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ices
    ADD CONSTRAINT ices_pkey PRIMARY KEY (id, d);


--
-- Name: kn15 kn15_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kn15
    ADD CONSTRAINT kn15_pkey PRIMARY KEY (num, dt);


--
-- Name: kppo kppo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kppo
    ADD CONSTRAINT kppo_pkey PRIMARY KEY (num, d);


--
-- Name: ssmc ssmc_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ssmc
    ADD CONSTRAINT ssmc_pkey PRIMARY KEY (dt, lat, lng, cntr);


--
-- Name: tmax tmax_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tmax
    ADD CONSTRAINT tmax_pkey PRIMARY KEY (num, d);


--
-- Name: tphn tphn_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tphn
    ADD CONSTRAINT tphn_pkey PRIMARY KEY (dt, name, lat, lng);


--
-- Name: twms twms_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.twms
    ADD CONSTRAINT twms_pkey PRIMARY KEY (d, lat, lng);


--
-- Name: TABLE aero; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.aero TO gmc;
GRANT SELECT ON TABLE public.aero TO synop;


--
-- Name: TABLE ffpa; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.ffpa TO gmc;
GRANT SELECT ON TABLE public.ffpa TO synop;


--
-- Name: TABLE fm12; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fm12 TO gmc;
GRANT SELECT ON TABLE public.fm12 TO synop;


--
-- Name: TABLE fm15; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fm15 TO gmc;
GRANT SELECT ON TABLE public.fm15 TO synop;


--
-- Name: TABLE fm35; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fm35 TO gmc;
GRANT SELECT ON TABLE public.fm35 TO synop;


--
-- Name: TABLE fm64; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fm64 TO gmc;
GRANT SELECT ON TABLE public.fm64 TO synop;


--
-- Name: TABLE fr12; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fr12 TO gmc;
GRANT SELECT ON TABLE public.fr12 TO synop;


--
-- Name: TABLE fs12; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fs12 TO gmc;
GRANT SELECT ON TABLE public.fs12 TO synop;


--
-- Name: TABLE fv12; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fv12 TO gmc;
GRANT SELECT ON TABLE public.fv12 TO synop;


--
-- Name: TABLE fw12; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.fw12 TO gmc;
GRANT SELECT ON TABLE public.fw12 TO synop;


--
-- Name: TABLE ices; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.ices TO gmc;
GRANT SELECT ON TABLE public.ices TO synop;


--
-- Name: TABLE kn15; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.kn15 TO gmc;
GRANT SELECT ON TABLE public.kn15 TO synop;


--
-- Name: TABLE kppo; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.kppo TO gmc;
GRANT SELECT ON TABLE public.kppo TO synop;


--
-- Name: TABLE ssmc; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.ssmc TO gmc;
GRANT SELECT ON TABLE public.ssmc TO synop;


--
-- Name: TABLE tmax; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.tmax TO gmc;
GRANT SELECT ON TABLE public.tmax TO synop;


--
-- Name: TABLE tphn; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.tphn TO gmc;
GRANT SELECT ON TABLE public.tphn TO synop;


--
-- Name: TABLE twms; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.twms TO gmc;
GRANT SELECT ON TABLE public.twms TO synop;


--
-- PostgreSQL database dump complete
--

