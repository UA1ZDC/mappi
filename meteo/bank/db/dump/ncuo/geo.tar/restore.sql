--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.7 (Debian 11.7-0+deb10u1)
-- Dumped by pg_dump version 11.7 (Debian 11.7-0+deb10u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE geo;
--
-- Name: geo; Type: DATABASE; Schema: -; Owner: gmc
--

CREATE DATABASE geo WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'ru_RU.UTF-8' LC_CTYPE = 'ru_RU.UTF-8';


ALTER DATABASE geo OWNER TO gmc;

\connect geo

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: dblink; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS dblink WITH SCHEMA public;


--
-- Name: EXTENSION dblink; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION dblink IS 'connect to other PostgreSQL databases from within a database';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: aero; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.aero (
    dt timestamp without time zone NOT NULL,
    lat smallint NOT NULL,
    lng smallint NOT NULL,
    num integer,
    nik character varying(24),
    mobl character varying(24),
    h0 smallint,
    t0 smallint,
    r0 smallint,
    d0 smallint,
    f0 smallint,
    h9 smallint,
    t9 smallint,
    r9 smallint,
    d9 smallint,
    f9 smallint,
    h8 smallint,
    t8 smallint,
    r8 smallint,
    d8 smallint,
    f8 smallint,
    h7 smallint,
    t7 smallint,
    r7 smallint,
    d7 smallint,
    f7 smallint,
    h5 smallint,
    t5 smallint,
    r5 smallint,
    d5 smallint,
    f5 smallint,
    h4 smallint,
    t4 smallint,
    r4 smallint,
    d4 smallint,
    f4 smallint,
    h3 smallint,
    t3 smallint,
    r3 smallint,
    d3 smallint,
    f3 smallint,
    h25 smallint,
    t25 smallint,
    r25 smallint,
    d25 smallint,
    f25 smallint,
    h2 smallint,
    t2 smallint,
    r2 smallint,
    d2 smallint,
    f2 smallint,
    h15 smallint,
    t15 smallint,
    r15 smallint,
    d15 smallint,
    f15 smallint,
    h1 smallint,
    t1 smallint,
    r1 smallint,
    d1 smallint,
    f1 smallint
);


ALTER TABLE public.aero OWNER TO postgres;

--
-- Name: pandp; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pandp (
    dt timestamp without time zone NOT NULL,
    lat smallint NOT NULL,
    lng smallint NOT NULL,
    dp smallint
);


ALTER TABLE public.pandp OWNER TO postgres;

--
-- Name: panpm; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.panpm (
    dt timestamp without time zone NOT NULL,
    lat smallint NOT NULL,
    lng smallint NOT NULL,
    pm smallint
);


ALTER TABLE public.panpm OWNER TO postgres;

--
-- Name: pmrl; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pmrl (
    dt timestamp without time zone NOT NULL,
    lat smallint NOT NULL,
    lng smallint NOT NULL,
    val smallint
);


ALTER TABLE public.pmrl OWNER TO postgres;

--
-- Name: synp; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.synp (
    dt timestamp without time zone NOT NULL,
    lat smallint NOT NULL,
    lng smallint NOT NULL,
    num integer,
    nik character varying(24),
    buoy character(5),
    h smallint,
    vv smallint,
    n smallint,
    dd smallint,
    ff smallint,
    ffm smallint,
    ts smallint,
    tdr smallint,
    pm smallint,
    ppm smallint DEFAULT 0,
    sd smallint,
    dp smallint,
    pdp smallint DEFAULT 0,
    w smallint,
    w1 smallint,
    w2 smallint,
    nh smallint,
    c character(3)
);


ALTER TABLE public.synp OWNER TO postgres;

--
-- Name: tpgh5; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tpgh5 (
    dt timestamp without time zone NOT NULL,
    lat smallint NOT NULL,
    lng smallint NOT NULL,
    dp smallint
);


ALTER TABLE public.tpgh5 OWNER TO postgres;

--
-- Name: tpgh7; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tpgh7 (
    dt timestamp without time zone NOT NULL,
    lat smallint NOT NULL,
    lng smallint NOT NULL,
    dp smallint
);


ALTER TABLE public.tpgh7 OWNER TO postgres;

--
-- Name: tpgh8; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tpgh8 (
    dt timestamp without time zone NOT NULL,
    lat smallint NOT NULL,
    lng smallint NOT NULL,
    dp smallint
);


ALTER TABLE public.tpgh8 OWNER TO postgres;

--
-- Name: tpgh9; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tpgh9 (
    dt timestamp without time zone NOT NULL,
    lat smallint NOT NULL,
    lng smallint NOT NULL,
    dp smallint
);


ALTER TABLE public.tpgh9 OWNER TO postgres;

--
-- Name: tpgt8; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tpgt8 (
    dt timestamp without time zone NOT NULL,
    lat smallint NOT NULL,
    lng smallint NOT NULL,
    dp smallint
);


ALTER TABLE public.tpgt8 OWNER TO postgres;

--
-- Name: aero aero_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.aero
    ADD CONSTRAINT aero_pkey PRIMARY KEY (dt, lat, lng);


--
-- Name: pandp pandp_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pandp
    ADD CONSTRAINT pandp_pkey PRIMARY KEY (dt, lat, lng);


--
-- Name: panpm panpm_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.panpm
    ADD CONSTRAINT panpm_pkey PRIMARY KEY (dt, lat, lng);


--
-- Name: pmrl pmrl_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pmrl
    ADD CONSTRAINT pmrl_pkey PRIMARY KEY (dt, lat, lng);


--
-- Name: synp synp_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.synp
    ADD CONSTRAINT synp_pkey PRIMARY KEY (dt, lat, lng);


--
-- Name: tpgh5 tpgh5_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tpgh5
    ADD CONSTRAINT tpgh5_pkey PRIMARY KEY (dt, lat, lng);


--
-- Name: tpgh7 tpgh7_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tpgh7
    ADD CONSTRAINT tpgh7_pkey PRIMARY KEY (dt, lat, lng);


--
-- Name: tpgh8 tpgh8_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tpgh8
    ADD CONSTRAINT tpgh8_pkey PRIMARY KEY (dt, lat, lng);


--
-- Name: tpgh9 tpgh9_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tpgh9
    ADD CONSTRAINT tpgh9_pkey PRIMARY KEY (dt, lat, lng);


--
-- Name: tpgt8 tpgt8_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tpgt8
    ADD CONSTRAINT tpgt8_pkey PRIMARY KEY (dt, lat, lng);


--
-- Name: TABLE aero; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.aero TO gmc;
GRANT SELECT ON TABLE public.aero TO synop;


--
-- Name: TABLE pandp; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.pandp TO gmc;
GRANT SELECT ON TABLE public.pandp TO synop;


--
-- Name: TABLE panpm; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.panpm TO gmc;
GRANT SELECT ON TABLE public.panpm TO synop;


--
-- Name: TABLE pmrl; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.pmrl TO gmc;
GRANT SELECT ON TABLE public.pmrl TO synop;


--
-- Name: TABLE synp; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.synp TO gmc;
GRANT SELECT ON TABLE public.synp TO synop;


--
-- Name: TABLE tpgh5; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.tpgh5 TO gmc;
GRANT SELECT ON TABLE public.tpgh5 TO synop;


--
-- Name: TABLE tpgh7; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.tpgh7 TO gmc;
GRANT SELECT ON TABLE public.tpgh7 TO synop;


--
-- Name: TABLE tpgh8; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.tpgh8 TO gmc;
GRANT SELECT ON TABLE public.tpgh8 TO synop;


--
-- Name: TABLE tpgh9; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.tpgh9 TO gmc;
GRANT SELECT ON TABLE public.tpgh9 TO synop;


--
-- Name: TABLE tpgt8; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.tpgt8 TO gmc;
GRANT SELECT ON TABLE public.tpgt8 TO synop;


--
-- PostgreSQL database dump complete
--

