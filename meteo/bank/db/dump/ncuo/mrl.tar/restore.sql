--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.7 (Debian 11.7-0+deb10u1)
-- Dumped by pg_dump version 11.7 (Debian 11.7-0+deb10u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE mrl;
--
-- Name: mrl; Type: DATABASE; Schema: -; Owner: gmc
--

CREATE DATABASE mrl WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'ru_RU.UTF-8' LC_CTYPE = 'ru_RU.UTF-8';


ALTER DATABASE mrl OWNER TO gmc;

\connect mrl

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: ech00; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ech00 (
    num integer NOT NULL,
    dt timestamp without time zone NOT NULL,
    size smallint,
    data text
);


ALTER TABLE public.ech00 OWNER TO postgres;

--
-- Name: ech01; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ech01 (
    num integer NOT NULL,
    dt timestamp without time zone NOT NULL,
    size smallint,
    data text
);


ALTER TABLE public.ech01 OWNER TO postgres;

--
-- Name: ech02; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ech02 (
    num integer NOT NULL,
    dt timestamp without time zone NOT NULL,
    size smallint,
    data text
);


ALTER TABLE public.ech02 OWNER TO postgres;

--
-- Name: ech03; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ech03 (
    num integer NOT NULL,
    dt timestamp without time zone NOT NULL,
    size smallint,
    data text
);


ALTER TABLE public.ech03 OWNER TO postgres;

--
-- Name: ech04; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ech04 (
    num integer NOT NULL,
    dt timestamp without time zone NOT NULL,
    size smallint,
    data text
);


ALTER TABLE public.ech04 OWNER TO postgres;

--
-- Name: ech05; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ech05 (
    num integer NOT NULL,
    dt timestamp without time zone NOT NULL,
    size smallint,
    data text
);


ALTER TABLE public.ech05 OWNER TO postgres;

--
-- Name: ech06; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ech06 (
    num integer NOT NULL,
    dt timestamp without time zone NOT NULL,
    size smallint,
    data text
);


ALTER TABLE public.ech06 OWNER TO postgres;

--
-- Name: ech07; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ech07 (
    num integer NOT NULL,
    dt timestamp without time zone NOT NULL,
    size smallint,
    data text
);


ALTER TABLE public.ech07 OWNER TO postgres;

--
-- Name: ech08; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ech08 (
    num integer NOT NULL,
    dt timestamp without time zone NOT NULL,
    size smallint,
    data text
);


ALTER TABLE public.ech08 OWNER TO postgres;

--
-- Name: ech09; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ech09 (
    num integer NOT NULL,
    dt timestamp without time zone NOT NULL,
    size smallint,
    data text
);


ALTER TABLE public.ech09 OWNER TO postgres;

--
-- Name: ech10; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ech10 (
    num integer NOT NULL,
    dt timestamp without time zone NOT NULL,
    size smallint,
    data text
);


ALTER TABLE public.ech10 OWNER TO postgres;

--
-- Name: height; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.height (
    num integer NOT NULL,
    dt timestamp without time zone NOT NULL,
    size smallint,
    data text
);


ALTER TABLE public.height OWNER TO postgres;

--
-- Name: intens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.intens (
    num integer NOT NULL,
    dt timestamp without time zone NOT NULL,
    size smallint,
    data text
);


ALTER TABLE public.intens OWNER TO postgres;

--
-- Name: phenom; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.phenom (
    num integer NOT NULL,
    dt timestamp without time zone NOT NULL,
    size smallint,
    data text
);


ALTER TABLE public.phenom OWNER TO postgres;

--
-- Name: sum01; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sum01 (
    num integer NOT NULL,
    dt timestamp without time zone NOT NULL,
    size smallint,
    data text
);


ALTER TABLE public.sum01 OWNER TO postgres;

--
-- Name: sum03; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sum03 (
    num integer NOT NULL,
    dt timestamp without time zone NOT NULL,
    size smallint,
    data text
);


ALTER TABLE public.sum03 OWNER TO postgres;

--
-- Name: sum06; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sum06 (
    num integer NOT NULL,
    dt timestamp without time zone NOT NULL,
    size smallint,
    data text
);


ALTER TABLE public.sum06 OWNER TO postgres;

--
-- Name: sum12; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sum12 (
    num integer NOT NULL,
    dt timestamp without time zone NOT NULL,
    size smallint,
    data text
);


ALTER TABLE public.sum12 OWNER TO postgres;

--
-- Name: sum24; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sum24 (
    num integer NOT NULL,
    dt timestamp without time zone NOT NULL,
    size smallint,
    data text
);


ALTER TABLE public.sum24 OWNER TO postgres;

--
-- Name: ech00 ech00_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ech00
    ADD CONSTRAINT ech00_pkey PRIMARY KEY (num, dt);


--
-- Name: ech01 ech01_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ech01
    ADD CONSTRAINT ech01_pkey PRIMARY KEY (num, dt);


--
-- Name: ech02 ech02_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ech02
    ADD CONSTRAINT ech02_pkey PRIMARY KEY (num, dt);


--
-- Name: ech03 ech03_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ech03
    ADD CONSTRAINT ech03_pkey PRIMARY KEY (num, dt);


--
-- Name: ech04 ech04_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ech04
    ADD CONSTRAINT ech04_pkey PRIMARY KEY (num, dt);


--
-- Name: ech05 ech05_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ech05
    ADD CONSTRAINT ech05_pkey PRIMARY KEY (num, dt);


--
-- Name: ech06 ech06_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ech06
    ADD CONSTRAINT ech06_pkey PRIMARY KEY (num, dt);


--
-- Name: ech07 ech07_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ech07
    ADD CONSTRAINT ech07_pkey PRIMARY KEY (num, dt);


--
-- Name: ech08 ech08_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ech08
    ADD CONSTRAINT ech08_pkey PRIMARY KEY (num, dt);


--
-- Name: ech09 ech09_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ech09
    ADD CONSTRAINT ech09_pkey PRIMARY KEY (num, dt);


--
-- Name: ech10 ech10_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ech10
    ADD CONSTRAINT ech10_pkey PRIMARY KEY (num, dt);


--
-- Name: height height_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.height
    ADD CONSTRAINT height_pkey PRIMARY KEY (num, dt);


--
-- Name: intens intens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.intens
    ADD CONSTRAINT intens_pkey PRIMARY KEY (num, dt);


--
-- Name: phenom phenom_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.phenom
    ADD CONSTRAINT phenom_pkey PRIMARY KEY (num, dt);


--
-- Name: sum01 sum01_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sum01
    ADD CONSTRAINT sum01_pkey PRIMARY KEY (num, dt);


--
-- Name: sum03 sum03_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sum03
    ADD CONSTRAINT sum03_pkey PRIMARY KEY (num, dt);


--
-- Name: sum06 sum06_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sum06
    ADD CONSTRAINT sum06_pkey PRIMARY KEY (num, dt);


--
-- Name: sum12 sum12_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sum12
    ADD CONSTRAINT sum12_pkey PRIMARY KEY (num, dt);


--
-- Name: sum24 sum24_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sum24
    ADD CONSTRAINT sum24_pkey PRIMARY KEY (num, dt);


--
-- Name: TABLE ech00; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.ech00 TO gmc;
GRANT SELECT ON TABLE public.ech00 TO synop;


--
-- Name: TABLE ech01; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.ech01 TO gmc;
GRANT SELECT ON TABLE public.ech01 TO synop;


--
-- Name: TABLE ech02; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.ech02 TO gmc;
GRANT SELECT ON TABLE public.ech02 TO synop;


--
-- Name: TABLE ech03; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.ech03 TO gmc;
GRANT SELECT ON TABLE public.ech03 TO synop;


--
-- Name: TABLE ech04; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.ech04 TO gmc;
GRANT SELECT ON TABLE public.ech04 TO synop;


--
-- Name: TABLE ech05; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.ech05 TO gmc;
GRANT SELECT ON TABLE public.ech05 TO synop;


--
-- Name: TABLE ech06; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.ech06 TO gmc;
GRANT SELECT ON TABLE public.ech06 TO synop;


--
-- Name: TABLE ech07; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.ech07 TO gmc;
GRANT SELECT ON TABLE public.ech07 TO synop;


--
-- Name: TABLE ech08; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.ech08 TO gmc;
GRANT SELECT ON TABLE public.ech08 TO synop;


--
-- Name: TABLE ech09; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.ech09 TO gmc;
GRANT SELECT ON TABLE public.ech09 TO synop;


--
-- Name: TABLE ech10; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.ech10 TO gmc;
GRANT SELECT ON TABLE public.ech10 TO synop;


--
-- Name: TABLE height; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.height TO gmc;
GRANT SELECT ON TABLE public.height TO synop;


--
-- Name: TABLE intens; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.intens TO gmc;
GRANT SELECT ON TABLE public.intens TO synop;


--
-- Name: TABLE phenom; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.phenom TO gmc;
GRANT SELECT ON TABLE public.phenom TO synop;


--
-- Name: TABLE sum01; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.sum01 TO gmc;
GRANT SELECT ON TABLE public.sum01 TO synop;


--
-- Name: TABLE sum03; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.sum03 TO gmc;
GRANT SELECT ON TABLE public.sum03 TO synop;


--
-- Name: TABLE sum06; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.sum06 TO gmc;
GRANT SELECT ON TABLE public.sum06 TO synop;


--
-- Name: TABLE sum12; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.sum12 TO gmc;
GRANT SELECT ON TABLE public.sum12 TO synop;


--
-- Name: TABLE sum24; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.sum24 TO gmc;
GRANT SELECT ON TABLE public.sum24 TO synop;


--
-- PostgreSQL database dump complete
--

